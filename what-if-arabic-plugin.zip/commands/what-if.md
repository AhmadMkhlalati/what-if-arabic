---
description: Make a What If episode with the what-if-arabic skill
---
Load the what-if-arabic skill and follow it, asking me at each step.

$ARGUMENTS
